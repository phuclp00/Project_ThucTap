<div class="p-6 sm:px-20 bg-white border-b border-gray-200">
    <div>
        <x-jet-application-logo class="block h-12 w-auto" />
    </div>
    <div class="mt-8 text-2xl">
        <p>
            <h1>Biểu giá điện 2021 !</h1>
        </p>
        <p>
            <h5 class="text-4x1"> Nguồn được lấy trực tiếp từ website :<a class="text-blue-500 hover:text-red-500"
                    href="https://download.vn/bieu-gia-dien-ban-le-35711">
                    https://download.vn/bieu-gia-dien-ban-le-35711 </a></h5>
        </p>
    </div>
</div>